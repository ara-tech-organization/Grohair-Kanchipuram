import React from 'react'
import BookAppointment from '../Components/Booknow/Booknow'
import Footer from '../Components/Footer'

function Booknow() {
  return (
    <div>
      <BookAppointment/>
      <Footer/>
    </div>
  )
}

export default Booknow
