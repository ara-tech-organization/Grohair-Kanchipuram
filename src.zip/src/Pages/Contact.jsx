import React from 'react'
import Footer from '../Components/Footer'
import Touch from '../Components/Contact/Touch'

export default function Contact() {
  return (
    <div>
        <Touch/>
      <Footer/>
    </div>
  )
}
